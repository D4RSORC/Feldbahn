Thanks alot for making my minecraft mod come true!
Here are just some Informations about the mod:

The Wagon should have alot of space in it and should work like a hopper Minecart (picks up Items)
The Wagon with brake is the same expect the Plank where you can stand on.

Is it Possible that you dont have the sitting animation if you sit in the big locomotive and the Wagon with brake?
The small locomotive should keep its sitting animation.

Is an animation of the wheels possible?


If you have any questions just ask me on fiverr, or contact me on my email: glen12@gmx.de

Cheers!